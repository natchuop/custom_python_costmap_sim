Physical AI figure validation

Overall status: PASS_WITH_WARNING
Runs: 40; seeds: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
Maps: 1; four methods present: True
Same-manifest pairing passed: True

Figures:
- A2_false_blockage_duration.png: PASS (figure and source measurements are available); source: steps_route_affected_by_attacker
- A3_security_performance_tradeoff.png: PASS (figure and source measurements are available); source: false_acceptance_rate, benign_delivery_cycle_duration_mean_steps
- A5_navigation_recovery_distribution.png: PASS (figure and source measurements are available); source: recovery_episodes.csv, recovery_time_steps, recovery_status
- 01_mission_deliveries.png: PASS (figure and source measurements are available); source: benign_total_deliveries_completed, no_attack condition
- 03_false_report_acceptance.png: PASS (figure and source measurements are available); source: false_acceptance_rate, malicious_report_deliveries
- 04_map_error_vs_attack_intensity.png: BLOCKED (required reference condition or measurements are unavailable); source: configured_attack_injections_per_1000_steps, map_error_mean
- 05_computational_scalability.png: BLOCKED (required reference condition or measurements are unavailable); source: fusion_runtime_samples.csv, stored_evidence_count, update_runtime_ms
- 06_delivery_time.png: PASS (figure and source measurements are available); source: benign_delivery_cycle_duration_mean_steps, no_attack condition
- 07_replans_per_delivery.png: PASS (figure and source measurements are available); source: replans_per_delivery, no_attack condition
- 08_report_influence_vs_age.png: PASS_WITH_WARNING (08_report_influence_vs_age.png: production Full trust influence ages out instead of remaining at 100% as illustrated in the document); source: production FusionEngine operational_weight probe
- 09_legitimate_operational_ignore_vs_delay.png: BLOCKED (required reference condition or measurements are unavailable); source: configured_honest_report_delay_steps, honest_operational_ignore_rate, honest_reports_operationally_ignored, honest_report_deliveries, honest_rejection_rate (diagnostic)

Attack types: fake_obstacle, false_clearance
Treatment levels: {"attack_intensity": [], "honest_delay_steps": []}
Pairing by condition: {"baseline": true, "no_attack": true}

Deviations:
- Simulator time is reported in steps because no auditable seconds conversion is configured.
- Recovery densities use recovered episodes only; never-affected and censored outcomes remain in plot data and validation.
- Influence curves reflect production FusionEngine behavior even where curves overlap the document mockup differently.

Warnings:
- 04_map_error_vs_attack_intensity.png: skipped: required reference condition or measurements are unavailable
- 05_computational_scalability.png: skipped: required reference condition or measurements are unavailable
- 09_legitimate_operational_ignore_vs_delay.png: skipped: required reference condition or measurements are unavailable
- 08_report_influence_vs_age.png: production Full trust influence ages out instead of remaining at 100% as illustrated in the document
